package org.crazyit.tetris;

import org.crazyit.tetris.ui.MainFrame;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MainFrame m = new MainFrame();
		m.setVisible(true);
	}

}
