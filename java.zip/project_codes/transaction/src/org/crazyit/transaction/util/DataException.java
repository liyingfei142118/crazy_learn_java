package org.crazyit.transaction.util;

public class DataException extends RuntimeException {

	public DataException(String message) {
		super(message);
	}
}
