package org.crazyit.transaction.service;

public class BusinessException extends RuntimeException {

	public BusinessException(String s) {
		super(s);
	}
}
