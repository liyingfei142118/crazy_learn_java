package org.crazyit.flashget.exception;

public class URLException extends RuntimeException {

	public URLException(String s) {
		super(s);
	}
}
