package org.crazyit.mysql.object.tree;

import javax.swing.Icon;

import org.crazyit.mysql.object.ViewObject;

public class RootNode implements ViewObject {

	
	public Icon getIcon() {
		return null;
	}

}
