package org.crazyit.ioc.context.object;

public class XmlApplicationContextObject1 {

}
