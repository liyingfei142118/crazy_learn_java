package org.crazyit.book.commons;

public class BusinessException extends RuntimeException {

	public BusinessException(String m) {
		super(m);
	}
}
